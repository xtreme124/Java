package ejb;

import javax.ejb.Stateless;
import java.sql.*;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

@Stateless
public class VisitorStateBean {

    private Connection conn = null;
    private ResultSet rs = null;
    private Statement stmt = null;
    private String query = null;

    @PostConstruct
    public void connect() {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "root");
            System.out.println("Database Connection Successful");
        } catch (Exception e) {
            System.out.println("Failed to connect to database : " + e.getMessage());
        }
    }

    @PreDestroy
    public void destroy() {
        try {
            conn.close();
            System.out.println("Database connection closed successfully");
        } catch (Exception e) {
            System.out.println("Failed to close database connection : " + e.getMessage());
        }
    }

    public void addVisitor(String host) {
        try {
            stmt = conn.createStatement();
            query = "UPDATE user_stat SET visits = visits + 1 WHERE hostname = '" + host + "'";
            int ans = stmt.executeUpdate(query);
            if (ans == 1) {
                System.out.println("Updated Success");
            } else {
                query = "INSERT INTO user_stat VALUES('" + host + "','1')";
                stmt.executeUpdate(query);
                System.out.println("Inserted New Host to database");
            }

        } catch (Exception e) {
            System.err.println("Cannot update: " + e.getMessage());
        }
    }

}
